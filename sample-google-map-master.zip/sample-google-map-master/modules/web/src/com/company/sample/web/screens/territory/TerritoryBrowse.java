package com.company.sample.web.screens.territory;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class TerritoryBrowse extends AbstractLookup {
}