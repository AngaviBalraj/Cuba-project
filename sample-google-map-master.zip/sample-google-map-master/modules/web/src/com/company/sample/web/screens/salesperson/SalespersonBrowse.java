package com.company.sample.web.screens.salesperson;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class SalespersonBrowse extends AbstractLookup {
}